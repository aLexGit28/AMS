import java.util.List;
import java.util.Scanner;

public class ViewFlightDetails {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Fetch all flights from your data source (database or API)
        List<Flight> flights = fetchFlights(); 

        // Display the header row
        System.out.println("Flight ID | Carrier ID | Origin | Destination | AirFare | Business | Economy | Executive");
        System.out.println("------- | -------- | -------- | -------- | -------- | -------- | -------- | --------");

        // Loop through each flight and display its details
        for (Flight flight : flights) {
            System.out.printf("%-9d | %-9d | %-8s | %-8s | %-7d | %-7d | %-7d | %-8d\n",
                    flight.getFlightID(), flight.getCarrierID(), flight.getOrigin(), flight.getDestination(), flight.getAirFare(),
                    flight.getSeatCapacityBusinessClass(), flight.getSeatCapacityEconomyClass(), flight.getSeatCapacityExecutiveClass());
        }

        scanner.close();
    }

    // Replace this with your actual flight fetching logic
    private static List<Flight> fetchFlights() {
        // TODO: Implement your logic to fetch flights from the database or API
        return null;
    }
}
