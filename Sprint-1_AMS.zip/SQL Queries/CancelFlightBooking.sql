BEGIN TRANSACTION;

-- Update Booking status to cancelled
UPDATE Booking
SET BookingStatus = 'Cancelled'
WHERE BookingID = @BookingID;

-- Update Flight schedule table to decrement ticket booked count
UPDATE FlightSchedule
SET BookedCount = BookedCount - 1
WHERE FlightID = (SELECT FlightID FROM Booking WHERE BookingID = @BookingID);

COMMIT;
