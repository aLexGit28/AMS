SELECT CarrierName, COUNT(*) AS MaxFlightCount
FROM Flights
WHERE FlightDate = 'YYYY-MM-DD'
GROUP BY CarrierName
ORDER BY MaxFlightCount DESC;
