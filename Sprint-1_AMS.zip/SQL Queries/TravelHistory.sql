SELECT F.FlightID, F.CarrierName, F.Origin, F.Destination, F.Airfare, B.DateOfTravel, B.BookingStatus
FROM Flights F
JOIN Booking B ON F.FlightID = B.FlightID
WHERE B.UserID = @UserID
ORDER BY B.DateOfTravel DESC;


