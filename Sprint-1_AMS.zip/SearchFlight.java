import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class SearchFlight {
    private HashMap<Integer, HashMap<String, Object>> flightData;

    public SearchFlight() {
        // Assume this HashMap holds flight information
        flightData = new HashMap<>();
        // Sample flight data
        HashMap<String, Object> flight1 = new HashMap<>();
        flight1.put("Flight ID", 1);
        flight1.put("Carrier Name", "Airline A");
        flight1.put("Origin", "New York");
        flight1.put("Destination", "Los Angeles");
        flight1.put("Date of Journey", new Date());
        flight1.put("AirFare", 500);
        flightData.put(1, flight1);

        HashMap<String, Object> flight2 = new HashMap<>();
        flight2.put("Flight ID", 2);
        flight2.put("Carrier Name", "Airline B");
        flight2.put("Origin", "London");
        flight2.put("Destination", "Paris");
        flight2.put("Date of Journey", new Date());
        flight2.put("AirFare", 400);
        flightData.put(2, flight2);
    }

    public void searchFlights(String origin, String destination, Date travelDate) {
        ArrayList<HashMap<String, Object>> matchingFlights = new ArrayList<>();
        for (HashMap<String, Object> flight : flightData.values()) {
            if (flight.get("Origin").equals(origin) && flight.get("Destination").equals(destination) && flight.get("Date of Journey").equals(travelDate)) {
                matchingFlights.add(flight);
            }
        }

        if (matchingFlights.isEmpty()) {
            System.out.println("No flights available for the given criteria.");
        } else {
            System.out.println("Available Flights:");
            for (HashMap<String, Object> flight : matchingFlights) {
                System.out.println("Flight ID: " + flight.get("Flight ID"));
                System.out.println("Carrier Name: " + flight.get("Carrier Name"));
                System.out.println("Origin: " + flight.get("Origin"));
                System.out.println("Destination: " + flight.get("Destination"));
                System.out.println("Date of Journey: " + flight.get("Date of Journey"));
                System.out.println("AirFare: " + flight.get("AirFare"));
                System.out.println();
            }
        }
    }

    public static void main(String[] args) {
        SearchFlight user = new SearchFlight();
        // Example usage
        user.searchFlights("New York", "Los Angeles", new Date());
        user.searchFlights("London", "Paris", new Date());
        user.searchFlights("New York", "Paris", new Date());
    }
}
