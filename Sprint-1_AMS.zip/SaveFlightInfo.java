import java.util.Scanner;

public class SaveFlightInfo {

    public static void main(String[] args) {
        // Initialize Scanner for user input
        Scanner scanner = new Scanner(System.in);

        // Gather flight information
        System.out.println("Enter Flight ID (integer):");
        int flightID = scanner.nextInt();

        System.out.println("Enter Carrier ID (integer):");
        int carrierID = scanner.nextInt();

        System.out.println("Enter Origin (integer):");
        int origin = scanner.nextInt();

        System.out.println("Enter Destination (string):");
        String destination = scanner.nextLine();
        destination = scanner.nextLine(); // Read again to capture full string

        System.out.println("Enter Air Fare (integer):");
        int airFare = scanner.nextInt();

        System.out.println("Enter Seat Capacity Business Class (integer):");
        int seatCapacityBusinessClass = scanner.nextInt();

        System.out.println("Enter Seat Capacity Economy Class (integer):");
        int seatCapacityEconomyClass = scanner.nextInt();

        System.out.println("Enter Seat Capacity Executive Class (integer):");
        int seatCapacityExecutiveClass = scanner.nextInt();

        // Close Scanner
        scanner.close();

        // Validate data before saving (add more checks as needed)
        if (flightID <= 0 || carrierID <= 0 || origin <= 0 || destination.isEmpty() || airFare <= 0
                || seatCapacityBusinessClass <= 0 || seatCapacityEconomyClass <= 0 || seatCapacityExecutiveClass <= 0) {
            System.err.println("Invalid data. Please ensure all fields are valid numbers.");
            return;
        }

        // Replace this with your actual API call or database interaction
        // This is just a simulation demonstrating data processing and success message
        try {
            // Perform API call or database operation to save flight data
            System.out.println("Saving Flight Information...");
            Thread.sleep(2000); // Simulated processing time
            System.out.println("Flight Information Saved Successfully in the System");
        } catch (Exception e) {
            System.err.println("Issue in Saving Flight Details. Please check the data and try again");
        }
    }
}