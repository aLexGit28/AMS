import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;

public class CancelBooking {
    private HashMap<Integer, Integer> bookedTickets; // Mapping of BookingID to FlightID

    public CancelBooking() {
        bookedTickets = new HashMap<>();
        // Assume booked tickets data is initialized here
        // For simplicity, let's assume some tickets are already booked
        bookedTickets.put(101, 1);
        bookedTickets.put(102, 2);
        bookedTickets.put(103, 1);
    }

    public void cancelBooking(int bookingId, Date travelDate) {
        if (bookedTickets.containsKey(bookingId)) {
            int flightId = bookedTickets.get(bookingId);
            // Calculate refund amount based on the cancellation policy
            double refundAmount = calculateRefundAmount(flightId, travelDate);

            // Decrement booked count
            decrementBookedCount(flightId);

            // Perform cancellation operations (e.g., refund process, update database, etc.)

            System.out.println("Booking with ID " + bookingId + " has been successfully canceled.");
            System.out.println("Refund amount: $" + refundAmount);
        } else {
            System.out.println("No booking found with the provided Booking ID.");
        }
    }

    private double calculateRefundAmount(int flightId, Date travelDate) {
        // Get the current date
        Date currentDate = new Date();

        // Calculate the difference in days between current date and travel date
        long diffInMillies = Math.abs(travelDate.getTime() - currentDate.getTime());
        long diffInDays = diffInMillies / (1000 * 60 * 60 * 24);

        // Determine refund percentage based on the cancellation policy
        double refundPercentage;
        if (diffInDays >= 20) {
            refundPercentage = 0.95;
        } else if (diffInDays >= 10) {
            refundPercentage = 0.70;
        } else if (diffInDays >= 2) {
            refundPercentage = 0.40;
        } else {
            refundPercentage = 0; // No refund if cancellation is within 2 days before travel date
        }

        // Retrieve ticket fare
        double ticketFare = getTicketFare(flightId);

        // Calculate refund amount
        return refundPercentage * ticketFare;
    }

    private void decrementBookedCount(int flightId) {
        // Logic to decrement booked count
        // For simplicity, let's assume booked count is maintained elsewhere and decremented here
        // Actual implementation may involve updating database or data structures
    }

    private double getTicketFare(int flightId) {
        // Logic to retrieve ticket fare based on flight ID
        // For simplicity, let's assume ticket fare is retrieved from a database or stored elsewhere
        // Actual implementation may involve querying a database or accessing stored data
        return 500; // Example ticket fare
    }

    public static void main(String[] args) {
        CancelBooking user = new CancelBooking();
        // Example cancellation
        user.cancelBooking(101, new Date()); // Cancel booking with Booking ID 101
        user.cancelBooking(104, new Date()); // No booking found with Booking ID 104

        // Allow user to enter Booking ID and Travel Date from console
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Booking ID: ");
        int bookingId = scanner.nextInt();
        System.out.print("Enter Travel Date (yyyy-mm-dd): ");
        String travelDateStr = scanner.next();
        // Convert travel date string to Date object
        Date travelDate = java.sql.Date.valueOf(travelDateStr);
        // Cancel the booking
        user.cancelBooking(bookingId, travelDate);
        scanner.close();
    }
}
