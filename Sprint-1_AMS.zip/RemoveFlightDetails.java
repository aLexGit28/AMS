import java.util.HashMap;

public class RemoveFlightDetails {
    private HashMap<Integer, HashMap<String, Object>> flightData;
    private HashMap<Integer, Boolean> activeBookings;

    public RemoveFlightDetails() {
        // Assume this HashMap holds flight information
        flightData = new HashMap<>();
        // Sample flight data
        HashMap<String, Object> flight1 = new HashMap<>();
        flight1.put("Flight ID", 1);
        flight1.put("Carrier ID", "ABC123");
        flightData.put(1, flight1);

        HashMap<String, Object> flight2 = new HashMap<>();
        flight2.put("Flight ID", 2);
        flight2.put("Carrier ID", "XYZ456");
        flightData.put(2, flight2);

        // Assume this HashMap holds active booking status for each flight
        activeBookings = new HashMap<>();
        activeBookings.put(1, false); // No active bookings for flight 1
        activeBookings.put(2, true); // Active bookings exist for flight 2
    }

    public void removeFlight(int flightId) {
        if (flightData.containsKey(flightId)) {
            if (activeBookings.get(flightId)) {
                System.out.println("Flight Information can't be removed as there are Active Booking open in the System. Please attempt to remove this flight either by cancelling all open ticket or try after serving all open bookings");
            } else {
                flightData.remove(flightId);
                System.out.println("Flight Information successfully removed from system");
            }
        } else {
            System.out.println("Either the data is incorrect or no Flight Information is available for the given Flight ID");
        }
    }

    public static void main(String[] args) {
        RemoveFlightDetails admin = new RemoveFlightDetails();
        admin.removeFlight(1); // Successfully removed
        admin.removeFlight(2); // Can't remove due to active bookings
        admin.removeFlight(3); // Flight ID not available
    }
}
