import java.util.HashMap;

public class EditFlightDetails {
    private HashMap<Integer, HashMap<String, Object>> flightData;

    public EditFlightDetails() {
        // Assume this HashMap holds flight information
        flightData = new HashMap<>();
        // Sample flight data
        HashMap<String, Object> flight1 = new HashMap<>();
        flight1.put("Flight ID", 1);
        flight1.put("Carrier ID", "ABC123");
        flight1.put("Origin", "New York");
        flight1.put("Destination", "Los Angeles");
        flight1.put("AirFare", 500);
        flight1.put("SeatCapacityBusinessClass", 20);
        flight1.put("SeatCapacityEconomyClass", 100);
        flight1.put("SeatCapacityExecutiveClass", 10);
        flightData.put(1, flight1);

        HashMap<String, Object> flight2 = new HashMap<>();
        flight2.put("Flight ID", 2);
        flight2.put("Carrier ID", "XYZ456");
        flight2.put("Origin", "London");
        flight2.put("Destination", "Paris");
        flight2.put("AirFare", 400);
        flight2.put("SeatCapacityBusinessClass", 15);
        flight2.put("SeatCapacityEconomyClass", 80);
        flight2.put("SeatCapacityExecutiveClass", 8);
        flightData.put(2, flight2);
    }

    public void searchFlight(int flightId) {
        if (flightData.containsKey(flightId)) {
            HashMap<String, Object> flightInfo = flightData.get(flightId);
            System.out.println("Flight ID: " + flightInfo.get("Flight ID"));
            System.out.println("Carrier ID: " + flightInfo.get("Carrier ID"));
            System.out.println("Origin: " + flightInfo.get("Origin"));
            System.out.println("Destination: " + flightInfo.get("Destination"));
            System.out.println("AirFare: " + flightInfo.get("AirFare"));
            System.out.println("SeatCapacityBusinessClass: " + flightInfo.get("SeatCapacityBusinessClass"));
            System.out.println("SeatCapacityEconomyClass: " + flightInfo.get("SeatCapacityEconomyClass"));
            System.out.println("SeatCapacityExecutiveClass: " + flightInfo.get("SeatCapacityExecutiveClass"));
        } else {
            System.out.println("Either the data is incorrect or no Flight Information is available for the given Flight ID");
        }
    }

    public static void main(String[] args) {
        EditFlightDetails admin = new EditFlightDetails();
        admin.searchFlight(1);
        admin.searchFlight(3); // Flight ID not available
    }
}
